# U — Répétition jusqu'à ... ( Until )

> Documentation de la commande FRED.

## Syntaxe

```fred
(.)U[<n>][T|F|E]<commandes><nl>
```

## Paramètres

| Élément | Description |
|---|---|
| `(.)` | Adresse ou plage de lignes optionnelle, selon la forme indiquée. |
| `<n>` | Nombre entier. |
| `<commandes>` | Commandes FRED à exécuter. |
| `<nl>` | Fin de ligne. |

## Description

Aucune description n'est disponible dans la source.

## Exemples

```fred
o-i\F (bufu) a Ajout de ligne dans buffer
b(bufa)u3 $za(bufu)*Ajout de ligne dans bufferAjout de ligne dans bufferAjout de ligne dans bufferu1e 20dn(err):#=-6 jf jm/La ligne n'existe pas!/La ligne n'existe pas!
```

## Options

Aucune option spécifique n'est documentée.

## Remarques

Aucune remarque spécifique n'est documentée.

## Compatibilité

| Implémentation | Statut |
|---|---|
| FRED historique | Compatible |
| FRED++ | À valider selon l'implémentation |

## Voir aussi

Aucun lien associé n'est encore défini.
